Plugin Name: Plethora Framework
Theme URI: http://plethorathemes.com/
Description: Framework including all core functionality for Plethora WP themes
Version: 1.1
Author: Plethora Themes
Author URI: http://www.plethorathemes.com



Features
--------

 - Redux Framework integration
 - Metabox Controller Class
 - Modules Controller Class
 - Custom Post Types Controller Class
 - Shortcodes Controller Class
 - Widgets Controller Class

Credits
--------

Changelog
---------
 v1.1 [22/10/2014]

 ADDED: Helper function to retrieve an image id by its url
 FIXED: 5.4.2 compatibility issue 

 v1.0 [31/09/2014]
 
- Initial release

Copyright
----------

Plethora Themes